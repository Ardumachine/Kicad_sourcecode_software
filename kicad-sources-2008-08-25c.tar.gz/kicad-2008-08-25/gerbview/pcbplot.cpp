		/************************************************/
		/* Menu General de Trace (PLOT) fichier PLOT.CC */
		/************************************************/

#include "fctsys.h"

#include "common.h"
#include "gerbview.h"
#include "pcbplot.h"
#include "id.h"

#include "protos.h"

/* variables locale : */

/* Routines Locales */

	/**************************************************************/
	/* void WinEDA_BasePcbFrame::ToPlotter(wxCommandEvent& event) */
	/***************************************************************/

void WinEDA_BasePcbFrame::ToPlotter(wxCommandEvent& event)
{
//	WinEDA_PlotFrame * frame = new WinEDA_PlotFrame(this);
//	frame->ShowModal(); frame->Destroy();
}

void Plume(int state)
{
}

